Website for Integrity First Flooring
--------------------------------------

To host:
1. Upload all files to the root directory of your hosting service.
2. Ensure 'index.html' is set as the default homepage.
3. Place your logo image at images/logo.png or replace with your own.

Includes:
- index.html
- styles.css
- gallery images in /images
